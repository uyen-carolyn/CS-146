/**
 * WebCrawler program found at: 
 * http://www.netinstructions.com/how-to-make-a-simple-web-crawler-in-java/
 */

// A minimal Web Crawler written in Java
// Usage: From command line 
//     java WebCrawler <URL> [N]
//  where URL is the url to start the crawl, and N (optional)
//  is the maximum number of pages to download.

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Spider {
	private static final int MAX_PAGES_TO_SEARCH = 30;
	private Set<String> pagesVisited = new HashSet<String>();
	private List<String> pagesToVisit = new LinkedList<String>();

	/**
	 * Our main launching point for the Spider's functionality. Internally it
	 * creates spider legs that make an HTTP request and parse the response (the web
	 * page).
	 * 
	 * @param url
	 *            - The starting point of the spider
	 * @param searchWord
	 *            - The word or string that you are searching for
	 */

	/**
	 * Returns the list of pages that have been visited
	 * 
	 * @return pagesVisited
	 */
	public Set<String> getPages() {
		return pagesVisited;
	}

	/**
	 * Searches for pages given the URL that will be used
	 * 
	 * @param url
	 *            the given URL
	 */
	public void search(String url) {
		while (this.pagesVisited.size() < MAX_PAGES_TO_SEARCH) {
			String currentUrl;
			SpiderLeg leg = new SpiderLeg();
			if (this.pagesToVisit.isEmpty()) {
				currentUrl = url;
				this.pagesVisited.add(url);
			} else {
				currentUrl = this.nextUrl();
			}
			leg.crawl(currentUrl); // Lots of stuff happening here. Look at the crawl method in
									// SpiderLeg
			this.pagesToVisit.addAll(leg.getLinks());
		}
		System.out.println("\n**Done** Visited " + this.pagesVisited.size() + " web page(s)");
	}

	/**
	 * Returns the next URL to visit (in the order that they were found). We also do
	 * a check to make sure this method doesn't return a URL that has already been
	 * visited.
	 * 
	 * @return nextURL
	 */
	private String nextUrl() {
		String nextUrl;
		do {
			nextUrl = this.pagesToVisit.remove(0);
		} while (this.pagesVisited.contains(nextUrl));
		this.pagesVisited.add(nextUrl);
		return nextUrl;
	}

	/**
	 * Returns the results as an ArrayList
	 * 
	 * @return usrAll
	 */
	public ArrayList<String> getList() {
		ArrayList<String> usrAll = new ArrayList<String>(pagesVisited);
		return usrAll;
	}

	public static class SpiderTest {
		/**
		 * This is our test. It creates a spider (which creates spider legs) and crawls
		 * the web.
		 * 
		 * @param args
		 *            - not used
		 */
		public static void main(String[] args) {
			Spider spider = new Spider();
			spider.search("http://google.com/search?q=keyword");
			spider.getPages();
			for (int i = 0; i < spider.getList().size() - 1; i++) {
				System.out.println(spider.getList().get(i));
			}

		}
	}
}